//
//  ViewController.swift
//  TableViewDemo
//
//  Created by Vadde,Hruthik Reddy on 4/13/23.
//

import UIKit
class Product{
    var Name : String?
    var Category : String?
    
    init(Name: String , Category: String ) {
        self.Name = Name
        self.Category = Category
    }
}
class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //expecting to return number of products 
        return products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Create a cell
        var mycell = TableViewOutlet.dequeueReusableCell(withIdentifier: "reusableCell", for: indexPath)
        //populate a cell
        mycell.textLabel?.text = products[indexPath.row].Name
        //return the cell
        return mycell
    }
    
    
    @IBOutlet weak var TableViewOutlet: UITableView!
    var products = [Product]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        TableViewOutlet.delegate = self
        TableViewOutlet.dataSource = self
        
        let p1 =  Product(Name: "Macbook", Category: "Laptop")
        products.append(p1)
        let p2 =  Product(Name: "Macbook Air", Category: "Laptop")
        products.append(p2)
        let p3 =  Product(Name: "Apple Airbuds", Category: "earphones")
        products.append(p3)
        let p4 =  Product(Name: "Samsung", Category: "Mobile")
        products.append(p4)
        let p5 =  Product(Name: "Nokia", Category: "watch")
        products.append(p5)
    }
        override func prepare(for segue: UIStoryboardSegue, sender: Any?){
            let transition = segue.identifier
            if transition == "Detailssegue"{
                let destination = segue.destination as! ResultViewController
                
        // Send the selected product row
                destination.product = products[(TableViewOutlet.indexPathForSelectedRow?.row)!]
            }
        }
    }




