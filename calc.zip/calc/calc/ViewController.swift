//
//  ViewController.swift
//  calc
//
//  Created by Vadde,Hruthik Reddy on 2/2/23.
//

import UIKit

class ViewController: UIViewController {
    var operand1 = -1.1
    var _operater = ""
    var operand2 = -1.1

    @IBOutlet weak var Resutlabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func Btn5clicked(_ sender: Any) {
        Resutlabel.text = Resutlabel.text! + "5"
        
    }
    @IBAction func Btnplusclicked(_ sender: Any) {
        Resutlabel.text = Resutlabel.text! + "+"
        if(_operater == " "){
            _operater = "+"
        }
        
        
    }
    @IBAction func Btn2clicked(_ sender: Any) {
        Resutlabel.text = Resutlabel.text! + "2"
        if(operand2 == -1.1){
            operand2 = 2
        }
        else{
            operand1 = 2
        }
        
    }
    @IBAction func Btnequalsclicked(_ sender: Any) {
        Resutlabel.text = "="
        Resutlabel.text = "\(operand1+operand2)"
    }
}

