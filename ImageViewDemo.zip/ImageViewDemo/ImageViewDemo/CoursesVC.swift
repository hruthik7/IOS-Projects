//
//  ViewController.swift
//  ImageViewDemo
//
//  Created by Vadde,Hruthik Reddy on 2/20/23.
//

import UIKit

class CoursesVC: UIViewController {
    
    // App Model
    let courses: Dictionary<String, Dictionary<String, String >> = [                "CyberSecurity" : ["title" : "CyberSecurity" , "crn" : "44652", "termOffered": "Fall" , "desc" : "Cybersecurity is the practice of deploying people, policies, processes and technologies to protect organizations, their critical systems and sensitive information from digital attacks." , "image": "cybersecurity"],                "Java" : ["title" : "Java" , "crn" : "44542", "termOffered": "Fall/Spring" , "desc" : "Java is a high-level, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible." , "image": "java"],                "iOS" : ["title" : "iOS" , "crn" : "44653", "termOffered": "Fall/Spring" , "desc" : "iOS is a mobile operating system developed by Apple Inc. exclusively for its hardware. It is the operating system that powers many of the company's mobile devices, including the iPhone." , "image": "iOS"],                "Database" : ["title" : "Advanced Database" , "crn" : "44553", "termOffered": "Fall/Spring" , "desc" : "In computing, a database is an organized collection of data stored and accessed electronically. Small databases can be stored on a file system, while large databases are hosted on computer clusters or cloud storage" , "image": "Database"]
    ]
    
    @IBOutlet weak var CousesSegctrl: UISegmentedControl!
    
    
    @IBOutlet weak var CoursesView: UIView!
    
    @IBOutlet weak var ImageView: UIImageView!
    

    @IBOutlet weak var CourseTitleLBL: UILabel!
    
    
    @IBOutlet weak var CourseCRNLBL: UILabel!
    
    
    @IBOutlet weak var CourseTermLBL: UILabel!
    
    @IBOutlet weak var CourseTextView: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

