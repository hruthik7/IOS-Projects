//
//  ViewController.swift
//  Displayimage
//
//  Created by Vadde,Hruthik Reddy on 2/21/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageviewOL: UIImageView!
    
    
    @IBOutlet weak var descriptionlabelOL: UILabel!
    
    override func viewDidLoad()
    {
        
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func displayimage(_ sender: Any) {
        //display the image
        imageviewOL.image = UIImage(named: "CristianoRonaldo")
        //display the text in label as well
        descriptionlabelOL.text = "Greatest of all time "
    }
}

