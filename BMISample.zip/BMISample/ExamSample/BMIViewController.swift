//
//  BMIViewController.swift
//  ExamSample
//
//  Created by Pilli,Sanjay Kumar on 4/8/23.
//

import UIKit

class BMIViewController: UIViewController {
    
    
    @IBOutlet weak var dheight: UILabel!
    
    
    @IBOutlet weak var dweight: UILabel!
    
    @IBOutlet weak var dbmivalue: UILabel!
    
    var height = ""

    var weight = ""

    var bmivalue = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        dheight.text! = dheight.text!+height
        dweight.text! = dweight.text!+weight
        dbmivalue.text! = dbmivalue.text!+bmivalue
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
