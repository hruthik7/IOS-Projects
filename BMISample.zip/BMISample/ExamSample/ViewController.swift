//
//  ViewController.swift
//  ExamSample
//
//  Created by Pilli,Sanjay Kumar on 4/8/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var height: UITextField!
    

    @IBOutlet weak var weight: UITextField!
    
    
    var bmivalue:Double = 0.0
    var hinm:Double = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func bmicalculator(_ sender: Any) {
        
        let h:Double = Double(height.text!)!
        let w:Double = Double(weight.text!)!
        
        hinm = h*(0.3048)
        
        bmivalue = w/(hinm*hinm)
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition = segue.identifier
        
        if(transition == "calculateBMI"){
            
            var destination = segue.destination as! BMIViewController
            
            destination.height = height.text!
            destination.weight = weight.text!
            
            destination.bmivalue = String(bmivalue)
            
            height.text = ""
            weight.text = ""
            
        }
        
    }
    
    
    

}

