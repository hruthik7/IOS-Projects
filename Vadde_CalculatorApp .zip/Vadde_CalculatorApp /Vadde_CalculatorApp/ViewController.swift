//
//  ViewController.swift
//  Vadde_CalculatorApp
//
//  Created by Vadde,Hruthik Reddy on 2/8/23.
//

import UIKit

class ViewController: UIViewController {
    var opnd1:Double = -7.9
    var opnd2:Double = -7.9
    var calculaterOperator:String = ""
    
    @IBOutlet weak var resultOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func buttonzero(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text!+"0"
    }
    @IBAction func buttonpercentage(_ sender: UIButton){
        opnd1 = Double(resultOutlet.text!) ?? 0.0
        resultOutlet.text = "%"
        calculaterOperator = "%"
        resultOutlet.text = ""
    }
    @IBAction func buttondot(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text!+"."
    }
    @IBAction func buttonplus(_ sender: UIButton) {
        opnd1 = Double(resultOutlet.text!) ?? 0.0
        resultOutlet.text = resultOutlet.text!+"+"
        calculaterOperator = "+"
        resultOutlet.text = ""
    }
    @IBAction func buttonminus(_ sender: UIButton) {
        opnd1 = Double(resultOutlet.text!) ?? 0.0
        resultOutlet.text = resultOutlet.text!+"-"
        calculaterOperator = "-"
        resultOutlet.text = ""
    }
    @IBAction func buttonmultiply(_ sender: UIButton) {
        opnd1 = Double(resultOutlet.text!) ?? 0.0
        resultOutlet.text = resultOutlet.text!+"X"
        calculaterOperator = "X"
        resultOutlet.text = ""
    }
    @IBAction func buttondivision(_ sender: UIButton) {
        opnd1 = Double(resultOutlet.text!) ?? 0.0
        resultOutlet.text = resultOutlet.text!+"÷"
        calculaterOperator = "÷"
        resultOutlet.text = ""
        
    }
    @IBAction func buttonminusplus(_ sender: UIButton) {
        if calculaterOperator == "-"{
            calculaterOperator = "+"
        }
        else if calculaterOperator == "+"{
            calculaterOperator = "-"
        }
    }
    @IBAction func buttonAC(_ sender: UIButton) {
        resultOutlet.text=""
        opnd1 = -7.9
        opnd2 = -7.9
        
    }
    @IBAction func buttonC(_ sender: UIButton) {
        var tp = resultOutlet.text!
        if(!tp.isEmpty){
            tp.removeLast()}
        if(tp.isEmpty){
            opnd1 = -7.9
            opnd2 = -7.9
        }
        resultOutlet.text = tp
    }
    @IBAction func buttonOne(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text!+"1"
    }
    @IBAction func buttonTwo(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text!+"2"
    }
    @IBAction func buttonThree(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text!+"3"
    }
    @IBAction func buttonFour(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text!+"4"
    }
    @IBAction func buttonFive(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text!+"5"
    }
    @IBAction func buttonSix(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text!+"6"
    }
    @IBAction func buttonSeven(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text!+"7"
    }
    @IBAction func buttonEight(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text!+"8"
    }
    @IBAction func buttonNine(_ sender: UIButton) {
        resultOutlet.text = resultOutlet.text!+"9"
    }
    @IBAction func buttonEqual(_ sender: UIButton) {
        opnd2 = Double(resultOutlet.text!) ?? 0.0
        if calculaterOperator.contains("+"){
            let res = opnd1+opnd2
            if(res.truncatingRemainder(dividingBy: 1)==0){
                resultOutlet.text = "\(Int(res))"
            }
            else {resultOutlet.text = "\((res))"}
        }
        else if calculaterOperator.contains("-"){
            let res = opnd1-opnd2
                if(res.truncatingRemainder(dividingBy: 1)==0){
                    resultOutlet.text = "\(Int(res))"
                }
                else {resultOutlet.text = "\((res))"}
            }
            else if calculaterOperator.contains("X"){
                let res = opnd1*opnd2
                    if(res.truncatingRemainder(dividingBy: 1)==0){
                        resultOutlet.text = "\(Int(res))"
                    }
                    else {resultOutlet.text = "\((res))"}
                }
                else if calculaterOperator.contains("÷"){
                    let res = opnd1/opnd2
                    if(opnd2 == 0){
                        resultOutlet.text = "Not a Number"
                    }
                    else
                    if(res.truncatingRemainder(dividingBy: 1)==0){
                        resultOutlet.text = "\(Int(res))"
                    }
                    else {resultOutlet.text = "\(round(res*100000)/100000.0)"}
                }
                if calculaterOperator.contains("%"){
                    let res = opnd1.truncatingRemainder(dividingBy: opnd2)
                    if(res.truncatingRemainder(dividingBy: 1)==0){
                        resultOutlet.text="\(Int(res))"
                    }
                    else {resultOutlet.text = "\(round(res*100000)/100000.0)"}
                }
            }
            
            
            
            
            
}

