//
//  ViewController.swift
//  Vadde_Assignment02
//
//  Created by Vadde,Hruthik Reddy on 2/2/23.
//

import UIKit

class ViewController: UIViewController {
    // Outlets and Textfields of app
    @IBOutlet weak var firstNameOutlet: UITextField!
    
    @IBOutlet weak var lastNameOutlet: UITextField!
    
    @IBOutlet weak var yearOutlet: UITextField!
    
    @IBOutlet weak var DetailsLabel: UILabel!
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    @IBOutlet weak var fullNameLabel: UILabel!
    
    @IBOutlet weak var ageLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
//submit button code
    @IBAction func SubmitBTN(_ sender: Any) {
        var fstname = firstNameOutlet.text!
        
        var lstname = lastNameOutlet.text!
        
        var DOBirth = yearOutlet.text!
        
        var birthyr = Int(DOBirth) ?? 0
        
        var presentyr = Calendar.current.component(.year,from: Date())
        
        
        DetailsLabel.text = "Details"
        
        fullNameLabel.text = "Full Name : \(lstname) \(fstname)"
        
        initialsLabel.text = "Initials : \(lstname.first!) \(fstname.first!)"
        
        ageLabel.text = "Age : \(presentyr-birthyr)"
    }
    //reset button code
    @IBAction func ResetBTN(_ sender: Any) {
        firstNameOutlet.text = ""
        lastNameOutlet.text = ""
        yearOutlet.text = ""
        fullNameLabel.text = ""
        initialsLabel.text = ""
        ageLabel.text = ""
        DetailsLabel.text = ""
        
    }
}

