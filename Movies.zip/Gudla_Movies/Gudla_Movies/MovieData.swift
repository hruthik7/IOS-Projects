//
//  MovieData.swift
//  Gudla_Movies
//
//  Created by Navya Sri on 4/25/23.
//

import Foundation
import UIKit
struct Movie{
    let title:String
    let image:UIImage
    let releasedYear:String
    let movieRating:String
    let boxOffice:String
    let moviePlot:String
    var cast: [String] = []
}

struct Genre{
    
    var category : String
    var movies:[Movie] = []
}

let genre1 = Genre(category: "Horror", movies: [
    Movie(title: "Airaa", image: UIImage(named: "airaa")!, releasedYear: "2019", movieRating: "5", boxOffice: "20", moviePlot: "light horror",cast: ["Nayanathara"]),
    Movie(title: "Conjuring", image: UIImage(named: "conjuring")!, releasedYear: "2013", movieRating: "4", boxOffice: "30", moviePlot: "too much horror",cast: ["xyz"]),
    Movie(title: "The NUN", image: UIImage(named: "nun")!, releasedYear: "2019", movieRating: "4", boxOffice: "450", moviePlot: "nuns are killed",cast: ["Rich Delia"]),
    Movie(title: "Annabelle", image: UIImage(named: "annabelle")!, releasedYear: "2014", movieRating: "5", boxOffice: "257", moviePlot: "drip blood on Mia's dol",cast: ["Douglas"]),
    Movie(title: "Insidious", image: UIImage(named: "insidious")!, releasedYear: "2018", movieRating: "3", boxOffice: "167", moviePlot: "Five Keys to confront and destroy her greatest fear",cast: ["Adam"])])

let genre2 = Genre(category: "Comedy", movies: [
    Movie(title: "Chichorre", image: UIImage(named: "chichore")!, releasedYear: "2019", movieRating: "5", boxOffice: "20", moviePlot: "Friends Reunion",cast: ["Sushanth"]),
    Movie(title: "3 Idiots", image: UIImage(named: "3idiots")!, releasedYear: "2009", movieRating: "4", boxOffice: "30", moviePlot: "Friends helping each other",cast: ["Amir khan"]),
    Movie(title: "Ra-One", image: UIImage(named: "raone")!, releasedYear: "2011", movieRating: "4", boxOffice: "450", moviePlot: "Robot saves lives",cast: ["Shah rukh Khan"]),
    Movie(title: "Kapoor & Sons", image: UIImage(named: "kands")!, releasedYear: "2014", movieRating: "5", boxOffice: "257", moviePlot: "numerous family problem",cast: ["Siddharth Malhotra"]),
    Movie(title: "Housefull 4", image: UIImage(named: "houseful")!, releasedYear: "2018", movieRating: "3", boxOffice: "167", moviePlot: "reincarnated lovers reunite in the present ",cast: ["Kriti Sanon"])])

let genre3 = Genre(category: "Thriller", movies: [
    Movie(title: "Article 15", image: UIImage(named: "article15")!, releasedYear: "2019", movieRating: "5", boxOffice: "20", moviePlot: " moral corruption of the village and its police force",cast: ["Isha Talwar"]),
    Movie(title: "Haseen Dilruba", image: UIImage(named: "hd")!, releasedYear: "2013", movieRating: "4", boxOffice: "30", moviePlot: "a woman reveals details of their thorny marriage",cast: ["Tapsee"]),
    Movie(title: "Evaru", image: UIImage(named: "evaru")!, releasedYear: "2019", movieRating: "4", boxOffice: "450", moviePlot: " inspector is assigned to investigate the case of a high-ranking officer",cast: ["Regina","Adivi Sesh"]),
    Movie(title: "Forensic", image: UIImage(named: "forensic")!, releasedYear: "2019", movieRating: "5", boxOffice: "257", moviePlot: "a police officer and forensic specialist who are on the trail together of a serial killer",cast: ["Mamta Mohandas"]),
    Movie(title: "Hit The First case", image: UIImage(named: "hit")!, releasedYear: "2018", movieRating: "3", boxOffice: "167", moviePlot: "investigating a missing girl case",cast: ["Viswak Sen"])])

let gen = [genre1,genre2,genre3]
