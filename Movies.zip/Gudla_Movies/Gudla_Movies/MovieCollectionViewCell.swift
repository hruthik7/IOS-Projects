//
//  MovieCollectionViewCell.swift
//  Gudla_Movies
//
//  Created by Navya Sri on 4/25/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    
    
    func assignMovies(movie: Movie){
        imageViewOL.image = movie.image
    }
    
}
