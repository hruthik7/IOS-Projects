//
//  SecondViewController.swift
//  Pilli_Exam02
//
//  Created by Pilli,Sanjay Kumar on 4/11/23.
//

import UIKit

class SecondViewController: UIViewController {
    
    var cid = ""
    var cname = ""
    var imageid = ""

    var courseObj = CourseDetails()
    
    @IBOutlet weak var studentIDOutlet: UILabel!
    
    
    @IBOutlet weak var enrolledOutlet: UILabel!
    
    
    @IBOutlet weak var courseImageOutlet: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        studentIDOutlet.text! = studentIDOutlet.text! + courseObj.courseID
        enrolledOutlet.text! = enrolledOutlet.text! + courseObj.courseID
        courseImageOutlet.image = UIImage(named: courseObj.courseImage)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
