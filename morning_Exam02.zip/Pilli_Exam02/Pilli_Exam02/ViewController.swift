//
//  ViewController.swift
//  Pilli_Exam02
//
//  Created by Pilli,Sanjay Kumar on 4/11/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var courseIDOutlet: UITextField!
    

    @IBOutlet weak var studentIDOutlet: UITextField!
    
    @IBOutlet weak var courseCheckOutlet: UIButton!
    
    @IBOutlet weak var statusLabelOutlet: UILabel!
    
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    
    
    @IBOutlet weak var enrollCourseOutlet: UIButton!
    
    var courseFound = CourseDetails()
    
    var coursearray = CoursesArray
    
    var isCourse = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        courseCheckOutlet.isEnabled = false
        
    }
    
    
    @IBAction func enablingCourseCheckOutlet(_ sender: Any) {
        courseCheckOutlet.isEnabled = true
    }
    
    
    
    @IBAction func courseChecking(_ sender: Any) {
        
        let enteredCourseID = courseIDOutlet.text!
        
        for course in coursearray {
            
            if enteredCourseID == course.courseID{
                courseFound = course
                
                isCourse = true
                
                statusLabelOutlet.text = "\(courseFound.courseID) is Open for registration"
                imageViewOutlet.image = UIImage(named: courseFound.courseImage)
            }
            else{
                statusLabelOutlet.text = "Course ID not found"
                imageViewOutlet.image = UIImage(named: "default")
            }
            break
        }
        
    }
    
    
    
    
    
    @IBAction func enrollingCourse(_ sender: Any) {
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
             if transition == "SecondViewSegue"{
                 let destination = segue.destination as! SecondViewController
                 
                 if isCourse{
                     destination.courseObj = courseFound
                 }
                 
                 
             }
    }
    
    
    
    

}

