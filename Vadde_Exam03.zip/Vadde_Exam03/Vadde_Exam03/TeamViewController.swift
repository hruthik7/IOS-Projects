//
//  TeamViewController.swift
//  Vadde_Exam03
//
//  Created by Vadde,Hruthik Reddy on 4/27/23.
//

import UIKit

class TeamViewController: UIViewController {
    
    
    var teamNamee = ""
    var teamImagee = ""
    var teamInfoo = ""
    
    @IBOutlet weak var teamImageView: UIImageView!
    
    
    
    @IBOutlet weak var teamInfo: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        teamInfo.text = teamInfoo
        teamImageView.image = UIImage(named: teamImagee)
        
        
    }
    

    @IBAction func animateImage(_ sender: Any) {
        
        var w =  teamImageView.frame.width
             w += 70
             var h = teamImageView.frame.height
             h += 70
             
            var x =  teamImageView.frame.origin.x-70
             
             var y = teamImageView.frame.origin.y-70
             
             var largerFrame = CGRect(x: x, y: y, width: w, height: h)
             
             UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 50, animations: {
                 self.teamImageView.frame = largerFrame
             })
        
        
        
    }
    
}
