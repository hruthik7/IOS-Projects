//
//  ViewController.swift
//  Vadde_Exam03
//
//  Created by Vadde,Hruthik Reddy on 4/27/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return teamsArray.count
    }
    
    func tableView(_ teamTableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        
        let tableCell = teamTableView.dequeueReusableCell(withIdentifier: "teamCell", for: indexPath)

        tableCell.textLabel?.text = teamsArray[indexPath.row].teamName
                
        return tableCell
        

    }
  
    
    
    

    
    @IBOutlet weak var teamTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        teamTableView.delegate = self
        teamTableView.dataSource = self
        
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    
        
        
        var transition = segue.identifier
                if(transition == "teamSegue")
        {
                    
                    let destination = segue.destination as! TeamViewController
                    
                    destination.teamImagee =  teamsArray[(teamTableView.indexPathForSelectedRow?.row)!].teamImage
                    
                    destination.teamInfoo = teamsArray[(teamTableView.indexPathForSelectedRow?.row)!].teamInfo

                }
            }
        
        
        
    
    
    
    

}

