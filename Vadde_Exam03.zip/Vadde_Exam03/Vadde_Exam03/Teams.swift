//
//  Teams.swift
//  Vadde_Exam03
//
//  Created by Vadde,Hruthik Reddy on 4/27/23.
//

import Foundation

struct TeamsList {
    var teamName = ""
    var teamImage = ""
    var teamInfo = ""

    }



let t1 = TeamsList(teamName: "Real Madrid", teamImage: "rm", teamInfo: "If you score first goal against RM you are in a trap")
let t2 = TeamsList(teamName: "Barcelona", teamImage: "bar", teamInfo: "Visca Barca Visca cataluya")

let t3 = TeamsList(teamName: "Manchester City", teamImage: "mc", teamInfo: "We have bernando silva")

let t4 = TeamsList(teamName: "Manchester United", teamImage: "rm", teamInfo: "We removed cristiano Ronaldo")

let t5 = TeamsList(teamName: "Paris Saint German", teamImage: "psg", teamInfo: "We have neymar,messsi and mbappe")


var teamsArray = [t1,t2,t3,t4,t5]
