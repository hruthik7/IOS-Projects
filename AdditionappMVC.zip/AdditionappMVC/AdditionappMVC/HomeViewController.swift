//
//  ViewController.swift
//  AdditionappMVC
//
//  Created by Vadde,Hruthik Reddy on 4/4/23.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var AmountoneOutlet: UITextField!
    
    
    @IBOutlet weak var Amount2Outlet: UITextField!
    
    var Tamount = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func CalcButton(_ sender: Any) {
        
        
        var amountone = Int(AmountoneOutlet.text!)
        print(amountone!)
        
        var amounttwo = Int(Amount2Outlet.text!)
        print(amounttwo!)
        Tamount = amountone! + amounttwo!
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if(transition == "Resultsegue"){
            var destination = segue.destination as! ResultViewController
            destination.amount1 = AmountoneOutlet.text!
            destination.amount2 = Amount2Outlet.text!
            destination.totalAmount = "\(Tamount)"
        }
    }
}

