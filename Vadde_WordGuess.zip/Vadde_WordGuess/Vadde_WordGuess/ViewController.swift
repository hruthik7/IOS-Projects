//
//  ViewController.swift
//  Vadde_WordGuess
//
//  Created by Vadde,Hruthik Reddy on 3/28/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet var wordsRemainingLabel: UILabel!
    @IBOutlet var totalWordsLabel: UILabel!
    
    @IBOutlet var wordGuessLabel: UILabel!
    
    @IBOutlet var userGuessLabel: UILabel!
    
    @IBOutlet var guessLetterField: UITextField!
    
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBOutlet weak var playAgainButton: UIButton!
    
    @IBOutlet weak var guessLetterButton: UIButton!
    
    @IBOutlet weak var displayImage: UIImageView!
    
    var guesswords = [["FOOTBALL","king of games"],["CRISTIANO","greatest of all time"],["MESSI","god gift"],["MALDINI","Fearless football player"],["ROOT","England captain for test cricket"]]
    var hint = ""
    var pictures = ["football","cristiano","messi","maldini","root"]
    var wordToGuess = ""
            var wordToGuessIndex = 0
            var lettersGuessed = ""
            let maxNumberOfWrongGuesses = 10
            var wrongGuessesRemaining = 10
            var guessCount = 0
            var wordsGuessedCount = 0
            var wordsMissedCount = 0
        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            wordToGuess = guesswords[wordToGuessIndex][0]
                    hint = guesswords[wordToGuessIndex][1]
                    hintLabel.text = "HINT: " + hint
            wordGuessLabel.text! = "Total number of words guessed successfully : 0"
                    totalWordsLabel.text = "Total number of words in game :  \(guesswords.count)"
                    wordsRemainingLabel.text = "Total number of words remaining in game : \(guesswords.count)"
                    formatUserGuessLabel()
                    guessLetterButton.isEnabled = false
            statusLabel.text = ""
                    playAgainButton.isHidden = true
        }
        
        func updateWordCountLabels(){
                wordGuessLabel.text = "Total number of words guessed successfully : \(wordsGuessedCount)"
                wordsRemainingLabel.text = "Total number of words remaining in game : \(guesswords.count - (wordsGuessedCount + wordsMissedCount))"
            }
            func updateUIAfterGuess(){
                guessLetterField.resignFirstResponder()
                guessLetterField.text = ""
            }
            func formatUserGuessLabel() {
                var revealedWord = ""
                lettersGuessed += guessLetterField.text!
                for letter in wordToGuess {
                    if lettersGuessed.contains(letter) {
                        revealedWord = revealedWord + " \(letter)"
                    } else {
                        revealedWord += " _"
                    }
                }
                revealedWord.removeFirst()
                userGuessLabel.text = revealedWord
            }
    func guessALetter() {
        formatUserGuessLabel()
        guessCount += 1
        let currentLetterGuessed = guessLetterField.text!
        if !wordToGuess.contains(currentLetterGuessed) {
            wrongGuessesRemaining = wrongGuessesRemaining - 1
        }
        let revealedWord = userGuessLabel.text!
        if wrongGuessesRemaining == 0 {
            playAgainButton.isHidden = false
            guessLetterField.isEnabled = false
            guessLetterButton.isEnabled = false
            guessCountLabel.text = "You're all out of guesses. Try again?"
            wordsMissedCount += 1
            updateWordCountLabels()
            WrongGuess()
        } else if !revealedWord.contains("_") {
            playAgainButton.isHidden = false
            guessLetterField.isEnabled = false
            guessLetterButton.isEnabled = false
            guessCountLabel.text = "You've got it! It took you \(guessCount) guesses to guess the word!"
            wordsGuessedCount += 1
            updateWordCountLabels()
            updatedisplayImage()
        } else {
            // Update our guess count
            let guess = ( guessCount == 1 ? "Guess" : "Guesses")
            guessCountLabel.text = "You've Made \(guessCount) \(guess)"
        }
        if (wordsGuessedCount + wordsMissedCount) == guesswords.count {
                        guessCountLabel.text = "You've tried all of the words! Restart from the beginning?"
                        statusLabel.text = "Congratulations, You are done, Please start over again"
                        displayImage.image = UIImage(named: "alldoneimg")
                    }
                }
            func updatedisplayImage(){
                            displayImage.isHidden = false
                displayImage.image = UIImage(named: pictures[wordToGuessIndex] )
            }
                func WrongGuess(){
                    displayImage.isHidden = false
                    displayImage.image = UIImage(named: "")
                }
            @IBAction func playAgainButtonPressed(_ sender: UIButton) {
                
                if(wordsGuessedCount == guesswords.count+1){
                    
                    displayImage.image = UIImage(named: "alldoneimg")
                    statusLabel.text! = "congratulations you are done"
                    
                }
            
                
                
                displayImage.isHidden = true
                                wordToGuessIndex += 1
                                if wordToGuessIndex == guesswords.count {
                                    wordToGuessIndex = 0
                                    wordsGuessedCount = 0
                                    wordsMissedCount = 0
                                    updateWordCountLabels()
                                }
                                wordToGuess = guesswords[wordToGuessIndex][0]
                                hint = guesswords[wordToGuessIndex][1]
                                hintLabel.text = "HINT: " + hint
                                
                                playAgainButton.isHidden = true
                                guessLetterField.isEnabled = true
                                guessLetterButton.isEnabled = false
                                
                                wrongGuessesRemaining = maxNumberOfWrongGuesses
                                lettersGuessed = ""
                                formatUserGuessLabel()
                                guessCountLabel.text = "You've Made 0 Guesses"
                                guessCount = 0
            }
    
            @IBAction func guessLetterFieldChanged(_ sender: UITextField) {
                if let letterGuessed = guessLetterField.text?.last {
                            guessLetterField.text = "\(letterGuessed)"
                            guessLetterButton.isEnabled = true
                        } else {
                            guessLetterButton.isEnabled = false
                        }
            }
            @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
                guessALetter()
                        updateUIAfterGuess()
                        let letter = guessLetterField.text
                        if letter?.isEmpty == true{
                            guessLetterButton.isEnabled = false
                        }
                        else{
                            guessLetterButton.isEnabled = true
                        }
            }
        }
    
    

    


