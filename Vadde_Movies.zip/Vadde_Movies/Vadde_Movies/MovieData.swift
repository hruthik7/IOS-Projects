//
//  MovieData.swift
//  Vadde_Movies
//
//  Created by Vadde,Hruthik Reddy on 4/25/23.
//

import Foundation
import UIKit
struct Movie{
    let title:String
    let image:UIImage
    let releasedYear:String
    let movieRating:String
    let boxOffice:String
    let moviePlot:String
    var cast: [String] = []
}

struct Genre{
    
    var category : String
    var movies:[Movie] = []
}

let gen1 = Genre(category: "Comedy", movies: [
    Movie(title: "F3", image: UIImage(named: "c1")!, releasedYear: "2021", movieRating: "5.2", boxOffice: "Average", moviePlot: "Full Packed comedy movie",cast: ["Venkatesh"]),
    Movie(title: "Markathamani", image: UIImage(named: "c2")!, releasedYear: "2016", movieRating: "7.0", boxOffice: "hit", moviePlot: "Comedy movie",cast: ["Rohith babu"]),
    Movie(title: "chitram", image: UIImage(named: "c3")!, releasedYear: "2005", movieRating: "4.8", boxOffice: "Average", moviePlot: "suspense comedy movie",cast: ["Kalyan"]),
    Movie(title: "ohhalu gusagusalade", image: UIImage(named: "c4")!, releasedYear: "2014", movieRating: "6.8", boxOffice: "Hit", moviePlot: "comedy and love movie",cast: ["Naga shourya, rashi khanna"]),
    Movie(title: "sankarabaranam", image: UIImage(named: "c5")!, releasedYear: "2016", movieRating: "7.9", boxOffice: "Hit", moviePlot: "comedy movie wuth twists",cast: ["Venkatesh","Suresh"])])

let gen2 = Genre(category: "Love Story", movies: [
    Movie(title: "The Perfect Match", image: UIImage(named: "l1")!, releasedYear: "2014", movieRating: "7.0", boxOffice: "Hit", moviePlot: "Love story between rwo memebers",cast: ["Vinkar","Sindy"]),
    Movie(title: "Titanic", image: UIImage(named: "l2")!, releasedYear: "2015", movieRating: "9.7", boxOffice: "SuperHit", moviePlot: "Greatest Lovestory of all time",cast: ["Damon","Soffy"]),
    Movie(title: "Love Story", image: UIImage(named: "l3")!, releasedYear: "2017", movieRating: "8.8", boxOffice: "Hit", moviePlot: "Beautifull Lovestory",cast: ["Lindan","Saman"]),
    Movie(title: "First Love", image: UIImage(named: "l4")!, releasedYear: "2019", movieRating: "7.9", boxOffice: "Hit", moviePlot: "First love is always special",cast: ["Stefan","John"]),
    Movie(title: "The fault in our stars", image: UIImage(named: "l5")!, releasedYear: "2014", movieRating: "9.7", boxOffice: "Blockboster", moviePlot: "Sometimes mistakes makes us closer",cast: ["Adam","jessi"])])

let gen3 = Genre(category: "Romance", movies: [
    Movie(title: "Yeto Velipoindi manasu", image: UIImage(named: "r1")!, releasedYear: "2012", movieRating: "9.0", boxOffice: "Hit", moviePlot: "Beautifull love story",cast: ["Samantha","Nani"]),
    Movie(title: "Love Story", image: UIImage(named: "r2")!, releasedYear: "2013", movieRating: "8.8", boxOffice: "Hit", moviePlot: "Love Story in Village",cast: ["Naga chaitanya","Pallavi"]),
    Movie(title: "A aa", image: UIImage(named: "r3")!, releasedYear: "2018", movieRating: "7.4", boxOffice: "Average", moviePlot: "Love between two members",cast: ["Nithin","Samantha"]),
    Movie(title: "Most Eligible Bachelor", image: UIImage(named: "r4")!, releasedYear: "2020", movieRating: "7.6", boxOffice: "Hit", moviePlot: "Love story in software company",cast: ["Akhil","Pooja"]),
    Movie(title: "Kalam Rasina Kathalu", image: UIImage(named: "r5")!, releasedYear: "2020", movieRating: "8.8", boxOffice: "Hit", moviePlot: "Simple love story",cast: ["Kalyani","Hari"])])


let gen = [gen1,gen2,gen3]




