//
//  ViewController.swift
//  Vadde_Exam01
//
//  Created by Vadde,Hruthik Reddy on 2/28/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displaylabel: UILabel!
    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var header: UILabel!
    @IBOutlet weak var input: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        imageview.image = UIImage(named: "default.jpeg")
    }
    
    @IBAction func USDcon(_ sender: Any) {
        if(input.text!.isEmpty)
              {
                  imageview.image=UIImage(named: "oops.jpeg")
                  displaylabel.text="please enter some Amount"
                  
              }
              else {
                  if(Double(input.text!)! == 0){
                      imageview.image=UIImage(named: "oops.jpeg")
                      displaylabel.text="₹0.0 Oops! cannot convert"
                      
                  }
                  else{
                      imageview.image=UIImage(named: "usd.jpeg")
                      var total : Double = 0.0
                      total = round((Double(input.text!)!/82.93)*100)/100
                      displaylabel.text="₹ \(Double(input.text!)!) in USD is $\(total)"
                  }
                  
              }
          }
          
    
    
    @IBAction func CADcon(_ sender: Any) {
        var input  = input.text!
         
         
         if(input.isEmpty)
         {
             imageview.image=UIImage(named: "oops.jpeg")
             displaylabel.text="please enter some amount"
             
         }
         else {
             if(Double(input)! == 0){
                 imageview.image=UIImage(named: "oops.jpeg")
                 displaylabel.text="₹0.0 Oops! cannot convert"
                 
             }
             else{
                 imageview.image=UIImage(named: "cad.jpeg")
                 var total : Double = 0.0
                 total = round(((Double(input)!)*(1.26/82.93))*100)/100
                 displaylabel.text="₹ \(Double(input)!) in CAD is $\(total)"
             }
        
    }
    
}
}
