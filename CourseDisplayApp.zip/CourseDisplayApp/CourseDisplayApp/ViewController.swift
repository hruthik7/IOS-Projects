//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Vadde,Hruthik Reddy on 3/19/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var displayimage: UIImageView!
    
    @IBOutlet weak var crsno: UILabel!
    
    @IBOutlet weak var crstitle: UILabel!
    
    @IBOutlet weak var semoffered: UILabel!
    @IBOutlet weak var nextBTN: UIButton!
    var imageno = 0
    @IBOutlet weak var preBTN: UIButton!
    let courses = [["img01","44555","Network Security","Fall 2022"],
                   ["img02","44558","ios Security","Fall 2023"],
                   ["img03","44552","application Security","Fall 2024"]]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //load the first image(image in the 0 position)
        displayimage.image = UIImage(named:courses[0][0])
        //load the course details
        crsno.text = courses[0][1]
        crstitle.text = courses[0][2]
        semoffered.text = courses[0][3]
        //previous button will be disabled
        preBTN.isEnabled = false
        
        //next button enabled
        nextBTN.isEnabled = true
    }
    
    
    
    @IBAction func previousbtnclicked(_ sender: UIButton) {
        //decrement the image no
        imageno -= 1
        //update the course details
        displayimage.image = UIImage(named: courses[imageno][0])
        crsno.text = courses[imageno][1]
        crstitle.text = courses[imageno][2]
        semoffered.text = courses[imageno][3]
        
        //next btn should be enabled
        nextBTN.isEnabled = true;
        
        
        
        //once you reach starting of the array, need to disable previous button
        if(imageno == 0){
            preBTN.isEnabled = false
        }
    }

    @IBAction func nextbtnclicked(_ sender: UIButton) {
        //increament the
        imageno  += 1
        //update the course details(image,courseno,title and semoffered)
        displayimage.image = UIImage(named: courses[imageno][0])
        crsno.text = courses[imageno][1]
        crstitle.text = courses[imageno][2]
        semoffered.text = courses[imageno][3]
        //when next click next button update the details of next course
        //previous button should be enabled
        preBTN.isEnabled = true
        //when you reach the end of the array next should be disabled.
        if(imageno == courses.count-1) {
            
            nextBTN.isEnabled = false
        }
        
    }
    
        
    }


