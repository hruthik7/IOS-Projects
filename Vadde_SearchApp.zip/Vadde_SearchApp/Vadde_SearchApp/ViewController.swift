//
//  ViewController.swift
//  Vadde_SearchApp
//
//  Created by Vadde,Hruthik Reddy on 3/20/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    var cricketImages = ["img1", "img2", "img3", "img6","img7"]
    var countryImages = ["por","fra","braz","arg","spa"]
    var footballImages = ["cr","lm","sr","nj","pm"]
    
    var cricketImagesDesc = ["Virat is captain of RCB","Rohit sharma is captain of MI","MS dhoni is captain of CSK","Rajat patidar is player of RCB","mohammad siraj is part of team india"]
    var countryImagesDesc = ["cristiano ronaldo born in portugal","mbappe born in france","neymar and kaka are born in brazil","messi and maradona born in argentina","spain is place of heaven"]
    var footballImagesDesc = ["greatest number 7 of all time","greatest player in foorball history","greatest defender of all time","god gifted him for playing football","most ruthless player in football history"]
    
    
    

    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var searchBTN: UIButton!
    
    
    @IBAction func editingchanged(_ sender: Any) {
        searchBTN.isEnabled = true
    }
    
    
    @IBOutlet weak var searchButtonAction: UIButton!
    
    @IBOutlet weak var resultImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        previousBTN.isHidden = true
        nextBTN.isHidden = true
        resetBTN.isHidden = true
        searchBTN.isEnabled = false
        
    }

    @IBOutlet weak var topicInfoText: UITextView!
    
    
    
    @IBOutlet weak var previousBTN: UIButton!
    
    
    
    @IBOutlet weak var nextBTN: UIButton!
    
    
    @IBOutlet weak var resetBTN: UIButton!
    
    
    @IBAction func ShowPrevImagesBtn(_ sender: Any) {
        nextBTN.isEnabled = true
        previousBTN.isEnabled = true
        var cricketIndex = 0
        var countryIndex = 0
        var footballIndex = 0
        let text = topicInfoText.text
        print(text as Any)
        if(cricketImagesDesc.contains(text!)){
            cricketIndex = cricketImagesDesc.firstIndex(of: text!)!
            print(cricketIndex)
        }
        else if(countryImagesDesc.contains(text!)){
            countryIndex = countryImagesDesc.firstIndex(of: text!)!
        }else if(footballImagesDesc.contains(text!)){
            footballIndex = footballImagesDesc.firstIndex(of: text!)!
        }
        
        if(cricketIndex == 1 && cricketImagesDesc.contains(text!)){
            resultImage.image = UIImage(named: cricketImages[0])
            topicInfoText.text = cricketImagesDesc[0]
            previousBTN.isEnabled = false
        }else if(countryIndex == 1 && countryImagesDesc.contains(text!)){
            resultImage.image = UIImage(named: countryImages[0])
            topicInfoText.text = countryImagesDesc[0]
            previousBTN.isEnabled = false
        }else if(footballIndex == 1 && footballImagesDesc.contains(text!)){
            resultImage.image = UIImage(named: footballImages[0])
            topicInfoText.text = footballImagesDesc[0]
            previousBTN.isEnabled = false
        }else if(cricketIndex < cricketImages.count && cricketImagesDesc.contains(text!)){
            resultImage.image = UIImage(named: cricketImages[cricketIndex-1])
            topicInfoText.text = cricketImagesDesc[cricketIndex-1]
        }else if(countryIndex < countryImages.count && countryImagesDesc.contains(text!)){
            resultImage.image = UIImage(named: countryImages[countryIndex-1])
            topicInfoText.text = countryImagesDesc[countryIndex-1]
        }else if(footballIndex < footballImages.count && footballImagesDesc.contains(text!)){
            resultImage.image = UIImage(named: footballImages[footballIndex-1])
            topicInfoText.text = footballImagesDesc[footballIndex-1]
        }
        
        
        
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: Any) {
        nextBTN.isEnabled = true
        previousBTN.isEnabled = true
        var cricketIndex = 0
        var countryIndex = 0
        var footballIndex = 0
        let text = topicInfoText.text
        print(text as Any)
        if(cricketImagesDesc.contains(text!)){
            cricketIndex = cricketImagesDesc.firstIndex(of: text!)!
            print(cricketIndex)
        }
        else if(countryImagesDesc.contains(text!)){
            countryIndex = countryImagesDesc.firstIndex(of: text!)!
        }else if(footballImagesDesc.contains(text!)){
            footballIndex = footballImagesDesc.firstIndex(of: text!)!
        }
        
        if(cricketIndex == 0 && cricketImagesDesc.contains(text!)){
            resultImage.image = UIImage(named: cricketImages[1])
            topicInfoText.text = cricketImagesDesc[1]
        }else if(countryIndex == 0 && countryImagesDesc.contains(text!)){
            resultImage.image = UIImage(named: countryImages[1])
            topicInfoText.text = countryImagesDesc[1]
        }else if(footballIndex == 0 && footballImagesDesc.contains(text!)){
            resultImage.image = UIImage(named: footballImages[1])
            topicInfoText.text = footballImagesDesc[1]
        }else if(cricketIndex == cricketImages.count-2 && cricketImagesDesc.contains(text!)){
            resultImage.image = UIImage(named: cricketImages[cricketIndex+1])
            topicInfoText.text = cricketImagesDesc[cricketIndex+1]
            nextBTN.isEnabled = false
        }else if(countryIndex == countryImages.count-2 && countryImagesDesc.contains(text!)){
            resultImage.image = UIImage(named: countryImages[countryIndex+1])
            topicInfoText.text = countryImagesDesc[countryIndex+1]
            nextBTN.isEnabled = false
        }else if(footballIndex == footballImages.count-2 && footballImagesDesc.contains(text!)){
            resultImage.image = UIImage(named: footballImages[footballIndex+1])
            topicInfoText.text = footballImagesDesc[footballIndex+1]
            nextBTN.isEnabled = false
        }else if(cricketIndex < cricketImages.count-2 && cricketImagesDesc.contains(text!)){
            resultImage.image = UIImage(named: cricketImages[cricketIndex+1])
            topicInfoText.text = cricketImagesDesc[cricketIndex+1]
        }else if(countryIndex < countryImages.count-2 && countryImagesDesc.contains(text!)){
            resultImage.image = UIImage(named: countryImages[countryIndex+1])
            topicInfoText.text = countryImagesDesc[countryIndex+1]
        }else if(footballIndex < footballImages.count-2 && footballImagesDesc.contains(text!)){
            resultImage.image = UIImage(named: footballImages[footballIndex+1])
            topicInfoText.text = footballImagesDesc[footballIndex+1
            ]
        }
        
    }
    
    
    @IBAction func ResetBtn(_ sender: Any) {
        
        previousBTN.isHidden = true
        nextBTN.isHidden = true
        resetBTN.isHidden = true
        searchBTN.isEnabled = false
        searchTextField.text = ""
        resultImage.image = UIImage(named: "img5")
        topicInfoText.text = ""
    }
    
    
    
    @IBAction func searchButton(_ sender: UIButton) {
        previousBTN.isHidden = false
        nextBTN.isHidden = false
        resetBTN.isHidden = false
        
        nextBTN.isEnabled = true
        if(searchTextField.text == "cricketers"){
            resultImage.image = UIImage(named: cricketImages[0])
            topicInfoText.text = cricketImagesDesc[0]
            previousBTN.isEnabled = false
        }else if(searchTextField.text == "countries"){
            resultImage.image = UIImage(named: countryImages[0])
            topicInfoText.text = countryImagesDesc[0]
            previousBTN.isEnabled = false
        }else if(searchTextField.text == "footballplayers"){
            resultImage.image = UIImage(named: footballImages[0])
            topicInfoText.text = footballImagesDesc[0]
            previousBTN.isEnabled = false
        }else{
            resultImage.image = UIImage(named: "img4")
            topicInfoText.text = ""
            previousBTN.isHidden = true
            nextBTN.isHidden = true
            resetBTN.isHidden = true
            searchBTN.isEnabled = true
            
        }
        
    }
    
    
}

