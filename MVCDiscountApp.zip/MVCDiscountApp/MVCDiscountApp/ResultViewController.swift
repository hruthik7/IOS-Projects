//
//  ResultViewController.swift
//  MVCDiscountApp
//
//  Created by Vadde,Hruthik Reddy on 3/30/23.
//

import UIKit

class ResultViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        DisplayAmount.text! += destinationAmount
        DiscountAmountOL.text! += destinationDiscRate
        ResultOL.text! += result

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBOutlet weak var DisplayAmount: UILabel!
    
    @IBOutlet weak var DiscountAmountOL: UILabel!
    
    @IBOutlet weak var ResultOL: UILabel!
    //need varibales to store the values
    var destinationAmount = ""
    var destinationDiscRate = ""
    var result = ""
    
    
    
}
