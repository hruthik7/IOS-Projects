//
//  ViewController.swift
//  MVCDiscountApp
//
//  Created by Vadde,Hruthik Reddy on 3/30/23.
//

import UIKit

class HomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
    }
    
    @IBOutlet weak var AmountOL: UITextField!
    
    @IBOutlet weak var DiscountOL: UITextField!
    var priceafterDiscount = 0.0
    
    @IBAction func DiscBTN(_ sender: Any) {
        //read the text and cinvert it into double
        var amount = Double(AmountOL.text!)
        var DiscRate = Double(DiscountOL.text!)
        print(DiscRate!)
        
        
        priceafterDiscount = amount! - (amount!*DiscRate!/100)
        print(priceafterDiscount)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //create a transition
        var transition = segue.identifier
        if (transition == "ResultSegue"){
            //create a destination
            var destination = segue.destination as! ResultViewController
            //assign values to result viewcontroller
            destination.destinationAmount = AmountOL.text!
            destination.destinationDiscRate = DiscountOL.text!
            destination.result = String(priceafterDiscount)
        }
    }
}

